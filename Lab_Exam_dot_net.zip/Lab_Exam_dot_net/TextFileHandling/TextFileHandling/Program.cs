﻿namespace TextFileHandling
{
    internal class Program
    {
        static void Main(string[] args)
        {
            WriteToTextFile();
            Console.WriteLine("Here is the content of the file mytest.txt:");
            ReadFromTextFile();
        }

        private static void WriteToTextFile()
        {
            // Path to the text file
            StreamWriter writer = File.CreateText("C:\\mytest.txt");
            writer.WriteLine("Hello and Welcome");
            writer.WriteLine("It is the first content");
            writer.WriteLine("Of the text file mytest.txt");
            writer.Close();
        }

        private static void ReadFromTextFile()
        {
            string? s;
            StreamReader reader = File.OpenText("C:\\mytest.txt");
            while ((s = reader.ReadLine()) != null)
            {
                Console.WriteLine(s);
            }
            reader.Close();
        }
    }
}